#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <chrono>
#include <atomic>

#include <immintrin.h>

#include "fighter/types.hpp"
#include "fighter/lsh_signer.hpp"
#include "fighter/resonance_head.hpp"
#include "fighter/ga_manager.hpp"

#if defined(_WIN32)
  #include <windows.h>
#elif defined(__linux__)
  #include <pthread.h>
  #include <sched.h>
#endif

// -----------------------------
// Build-time knobs
// -----------------------------
#ifndef FIGHTER_SETS_POW2
#define FIGHTER_SETS_POW2 65536u // 65536 * 128B = 8MB head
#endif

#ifndef FIGHTER_PAYLOAD_COUNT
#define FIGHTER_PAYLOAD_COUNT 65536u // payload rows (8 floats each)
#endif

#ifndef FIGHTER_REFRESH_MASK
#define FIGHTER_REFRESH_MASK 0xFFFFu // worker publishes sig + consumes one cmd every 65536 steps
#endif

#ifndef FIGHTER_RUN_SECONDS
#define FIGHTER_RUN_SECONDS 2
#endif

static inline void* aligned_alloc_bytes(size_t align, size_t bytes) {
#if defined(_MSC_VER)
    return _aligned_malloc(bytes, align);
#else
    void* p = nullptr;
    if (posix_memalign(&p, align, bytes) != 0) return nullptr;
    return p;
#endif
}

static inline void aligned_free_bytes(void* p) {
#if defined(_MSC_VER)
    _aligned_free(p);
#else
    free(p);
#endif
}

static void pin_thread_to_cpu(unsigned cpu_index) {
#if defined(_WIN32)
    DWORD_PTR mask = (DWORD_PTR)1ull << (cpu_index & 63u);
    SetThreadAffinityMask(GetCurrentThread(), mask);
#elif defined(__linux__)
    cpu_set_t cs;
    CPU_ZERO(&cs);
    CPU_SET((int)cpu_index, &cs);
    pthread_setaffinity_np(pthread_self(), sizeof(cs), &cs);
#else
    (void)cpu_index;
#endif
}

// Minimal hot-loop state evolution stub (replace with your real kernel).
// Requirements: branchless, AVX2/FMA friendly, stable throughput.
static inline void evolve_state16(float* st16) {
    __m256 a = _mm256_load_ps(st16);
    __m256 b = _mm256_load_ps(st16 + 8);

    const __m256 k1 = _mm256_set1_ps(0.99991f);
    const __m256 k2 = _mm256_set1_ps(0.00037f);

    a = _mm256_fmadd_ps(a, k1, k2);
    b = _mm256_fmadd_ps(b, k1, a);

    _mm256_store_ps(st16, a);
    _mm256_store_ps(st16 + 8, b);
}

static inline void apply_injection(float* st8, const float* payload8, int16_t mix_q14) {
    const __m256 v_mix = _mm256_set1_ps(float(mix_q14) * (1.0f / 16384.0f));
    __m256 s = _mm256_load_ps(st8);
    __m256 p = _mm256_load_ps(payload8);
    _mm256_store_ps(st8, _mm256_fmadd_ps(p, v_mix, s));
}

// ----------------------------------
// Worker: hot loop (P-core)
// ----------------------------------
static void worker_loop(std::atomic<bool>* run,
                        ResonanceBridge* bridge,
                        StateSketch* shared_sig,
                        const LSHProjTable* lsh,
                        const float* payloads,
                        uint32_t payload_count,
                        std::atomic<uint64_t>* step_counter) {
    pin_thread_to_cpu(0);

    alignas(32) float state16[16];
    for (int i = 0; i < 16; ++i) state16[i] = (i == 0) ? 0.1f : 0.01f;

    uint32_t local_sig[4];
    StepCommand cmd{};

    uint32_t local_steps = 0;
    uint64_t i = 0;

    while (run->load(std::memory_order_relaxed)) {
        evolve_state16(state16);
        ++local_steps;

        if (((uint32_t)i & FIGHTER_REFRESH_MASK) == 0u) {
            if (step_counter && local_steps) {
                step_counter->fetch_add(local_steps, std::memory_order_relaxed);
                local_steps = 0;
            }

            make_state_sig_lsh128(state16, *lsh, local_sig);

            // publish sig via seqlock
            uint32_t s0 = shared_sig->seq.load(std::memory_order_relaxed);
            shared_sig->seq.store(s0 + 1, std::memory_order_release); // odd
            std::memcpy(shared_sig->sig, local_sig, 16);
            shared_sig->seq.store(s0 + 2, std::memory_order_release); // even

            // consume at most one command per refresh
            if (bridge->pop(cmd)) {
                if (cmd.flags & CMD_HAS_INJECT) {
                    const float* p = payloads + (size_t(cmd.inject_idx % payload_count) * 8u);
                    const int off = (cmd.target_slot & 1u) ? 8 : 0;
                    apply_injection(state16 + off, p, cmd.mix_q14);
                }
                // token_id is available to be incorporated into your kernel
                // e.g. token-conditioned permutation selection, etc.
            }
        }

        ++i;
    }

    if (step_counter && local_steps) {
        step_counter->fetch_add(local_steps, std::memory_order_relaxed);
    }

    volatile float sink = state16[0];
    (void)sink;
}

// ----------------------------------
// Manager: head lookup + online reinforce
// ----------------------------------
static void manager_loop(std::atomic<bool>* run,
                         ResonanceBridge* bridge,
                         const StateSketch* shared_sig,
                         ResonanceHead<FIGHTER_SETS_POW2>* head,
                         ManagerMetrics* mm,
                         const float* /*payloads*/,
                         uint32_t /*payload_count*/,
                         const uint32_t* teacher_seeds512) {
    pin_thread_to_cpu(1);

    uint32_t sig[4];
    uint16_t age = 1;
    uint32_t last_seq = 0;

    while (run->load(std::memory_order_relaxed)) {
        // seqlock read
        uint32_t a0, a1;
        do {
            a0 = shared_sig->seq.load(std::memory_order_acquire);
            if (a0 & 1u) continue;
            std::memcpy(sig, shared_sig->sig, 16);
            a1 = shared_sig->seq.load(std::memory_order_acquire);
        } while (a0 != a1 || (a1 & 1u));

        // act once per published signature
        if (a1 == last_seq) {
            _mm_pause();
            continue;
        }
        last_seq = a1;

        mm->lookups++;

        // head lookup
        auto lr = head->lookup(sig, (uint16_t)mm->threshold);

        // Synthetic teacher target token (replace with offline trace / real teacher)
        const uint16_t teacher_tok = (uint16_t)((sig[0] ^ sig[3] ^ teacher_seeds512[(sig[1] & 511u)]) & 0x7FFFu);

        StepCommand cmd{};
        bool push_ok = true;

        if (lr.hit) {
            mm->hits++;

            cmd.token_id = lr.tok0;
            cmd.match_bits = lr.best_match;
            cmd.target_slot = 0;
            cmd.mix_q14 = 1024; // ~0.0625
            cmd.inject_idx = (sig[2] ^ sig[0]) & 0xFFFFu;
            cmd.flags = CMD_HAS_INJECT;

            // online correction: if head disagrees with teacher, reinforce teacher mapping
            if ((uint16_t)cmd.token_id != teacher_tok) {
                head->reinforce(sig, teacher_tok, 80, age);
                // make system more conservative
                if (mm->threshold < 124) mm->threshold++;
            } else {
                head->reinforce(sig, (uint16_t)cmd.token_id, 100, age);
            }

            push_ok = bridge->push(cmd);
            if (push_ok) mm->pushed++; else mm->overflows++;

        } else {
            mm->misses++;

            // miss: fill head with teacher mapping
            head->reinforce(sig, teacher_tok, 60, age);

            cmd.token_id = teacher_tok;
            cmd.match_bits = lr.best_match;
            cmd.target_slot = 0;
            cmd.mix_q14 = 0;
            cmd.inject_idx = 0;
            cmd.flags = CMD_FROM_TEACHER;

            push_ok = bridge->push(cmd);
            if (push_ok) mm->pushed++; else mm->overflows++;
        }

        ga_adjust_threshold(*mm, lr.best_match, lr.second_match, lr.hit, push_ok);
        age++;
    }
}

int main() {
    static_assert((FIGHTER_REFRESH_MASK & (FIGHTER_REFRESH_MASK + 1u)) == 0u,
                  "FIGHTER_REFRESH_MASK must be 2^n-1 to behave as period mask");

    // Head backing: sets * 128B (two cache lines per set)
    ResonanceSet* backing = (ResonanceSet*)aligned_alloc_bytes(128, sizeof(ResonanceSet) * (size_t)FIGHTER_SETS_POW2);
    if (!backing) {
        std::fprintf(stderr, "alloc head backing failed\n");
        return 1;
    }

    ResonanceHead<FIGHTER_SETS_POW2> head;
    head.init(backing);

    // LSH projection table
    uint32_t seeds512[512];
    uint32_t s = 0xC001D00Du;
    for (int i = 0; i < 512; ++i) seeds512[i] = xorshift32(s);

    LSHProjTable lsh;
    build_lsh_table(lsh, seeds512);

    // Payloads (demo)
    const uint32_t payload_count = (uint32_t)FIGHTER_PAYLOAD_COUNT;
    float* payloads = (float*)aligned_alloc_bytes(32, (size_t)payload_count * 8u * sizeof(float));
    if (!payloads) {
        std::fprintf(stderr, "alloc payloads failed\n");
        aligned_free_bytes(backing);
        return 1;
    }
    for (uint32_t i = 0; i < payload_count * 8u; ++i) {
        payloads[i] = float(int(i & 255u) - 128) * 0.001f;
    }

    // Shared structures
    ResonanceBridge bridge;
    StateSketch shared_sig;
    ManagerMetrics mm{};

    // Synthetic teacher seeds
    uint32_t teacher_seeds512[512];
    uint32_t ts = 0x12345678u;
    for (int i = 0; i < 512; ++i) teacher_seeds512[i] = xorshift32(ts);

    std::atomic<bool> run{true};
    std::atomic<uint64_t> worker_steps{0};

    std::thread worker([&]() {
        worker_loop(&run, &bridge, &shared_sig, &lsh, payloads, payload_count, &worker_steps);
    });

    std::thread manager([&]() {
        manager_loop(&run, &bridge, &shared_sig, &head, &mm, payloads, payload_count, teacher_seeds512);
    });

    const auto t0 = std::chrono::high_resolution_clock::now();
    std::this_thread::sleep_for(std::chrono::seconds(FIGHTER_RUN_SECONDS));
    const auto t1 = std::chrono::high_resolution_clock::now();

    run.store(false, std::memory_order_relaxed);
    worker.join();
    manager.join();

    const double sec = std::chrono::duration<double>(t1 - t0).count();
    const unsigned long long steps = (unsigned long long)worker_steps.load(std::memory_order_relaxed);
    const double steps_per_s = double(steps) / sec;
    const double lookups_per_s = double(mm.lookups) / sec;

    std::printf("Fighter V5 (CPU-only)\n");
    std::printf("  steps:     %llu (%.2f M/s)\n", steps, steps_per_s / 1e6);
    std::printf("  lookups:   %llu (%.2f /s)\n", (unsigned long long)mm.lookups, lookups_per_s);
    std::printf("  hits:      %llu\n", (unsigned long long)mm.hits);
    std::printf("  misses:    %llu\n", (unsigned long long)mm.misses);
    std::printf("  pushed:    %llu\n", (unsigned long long)mm.pushed);
    std::printf("  overflows: %llu\n", (unsigned long long)mm.overflows);
    std::printf("  threshold: %u (match bits out of 128)\n", mm.threshold);

    aligned_free_bytes(payloads);
    aligned_free_bytes(backing);
    return 0;
}
