#pragma once

#include <cstdint>
#include <cstring>
#include <immintrin.h>

#ifndef FIGHTER_TOPK
#define FIGHTER_TOPK 2
#endif

#ifndef FIGHTER_WAYS
#define FIGHTER_WAYS 4
#endif

// --- POPCNT helpers ---
static inline uint64_t popcnt64_u(uint64_t x) {
#if defined(_MSC_VER)
    return (uint64_t)__popcnt64(x);
#elif defined(__GNUC__) || defined(__clang__)
    return (uint64_t)__builtin_popcountll(x);
#else
    // fallback (slow)
    uint64_t c = 0;
    while (x) { x &= (x - 1); ++c; }
    return c;
#endif
}

// 32 bytes entry. Designed so that a set = 4 entries = 128 bytes (2 cache lines).
struct alignas(32) ResonanceEntry {
    uint32_t sig[4];                  // 128-bit key
    uint16_t tok[FIGHTER_TOPK];       // top-k tokens
    int8_t   q8[FIGHTER_TOPK];        // top-k scores/energy (quant)
    uint16_t hits;                    // reinforcement count (fitness)
    uint16_t age;                     // last-touch / aging
    uint16_t pad[3];                  // pad to 32B
};
static_assert(sizeof(ResonanceEntry) == 32, "ResonanceEntry must be 32B");

struct alignas(128) ResonanceSet {
    ResonanceEntry ways[FIGHTER_WAYS];
};
static_assert(sizeof(ResonanceSet) == 128, "ResonanceSet must be 128B");

// Hash: 128-bit -> set index. Power-of-two sets.
static inline uint32_t mix_u32(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7feb352dU;
    x ^= x >> 15;
    x *= 0x846ca68bU;
    x ^= x >> 16;
    return x;
}

static inline uint32_t set_index_128(const uint32_t sig[4], uint32_t mask_pow2) {
    // Fold 128 -> 32 with mixing.
    uint32_t x = sig[0] ^ sig[1] ^ sig[2] ^ sig[3];
    x = mix_u32(x);
    // Also mix in cross terms to reduce adversarial collisions.
    x ^= mix_u32(sig[0] + 0x9e3779b9u);
    x ^= mix_u32(sig[2] + 0x7f4a7c15u);
    return x & mask_pow2;
}

// Similarity metric: match_bits = 128 - popcnt(xor).
// This is density-stable (unlike AND-popcnt).
static inline uint16_t match_bits_128(const uint32_t a[4], const uint32_t b[4]) {
    __m128i va = _mm_loadu_si128((const __m128i*)a);
    __m128i vb = _mm_loadu_si128((const __m128i*)b);
    __m128i vx = _mm_xor_si128(va, vb);

    uint64_t lo = (uint64_t)_mm_cvtsi128_si64(vx);
    __m128i hi_v = _mm_srli_si128(vx, 8);
    uint64_t hi = (uint64_t)_mm_cvtsi128_si64(hi_v);

    uint64_t dist = popcnt64_u(lo) + popcnt64_u(hi);
    return (uint16_t)(128u - (uint16_t)dist);
}

// Production-oriented 4-way set-associative head.
// - No dynamic allocations inside methods.
// - Can be used in hot paths.
// - Reinforce uses simple eviction policy (empty -> least hits -> oldest).

template<uint32_t SETS_POW2>
class ResonanceHead {
public:
    static_assert((SETS_POW2 & (SETS_POW2 - 1u)) == 0u, "SETS_POW2 must be power-of-two");
    static constexpr uint32_t MASK = SETS_POW2 - 1u;

    ResonanceHead() = default;

    void init(ResonanceSet* backing) {
        data_ = backing;
        std::memset(data_, 0, sizeof(ResonanceSet) * SETS_POW2);
    }

    struct LookupResult {
        bool hit;
        uint16_t tok0;
        uint16_t best_match;
        uint16_t second_match;
        uint8_t  best_way;
        uint8_t  _pad;
    };

    // Lookup in 4-way set.
    // threshold in match bits (0..128). Higher = stricter.
    LookupResult lookup(const uint32_t sig[4], uint16_t threshold) const {
        LookupResult r{};
        r.hit = false;
        r.tok0 = 0;
        r.best_match = 0;
        r.second_match = 0;
        r.best_way = 0;

        const uint32_t idx = set_index_128(sig, MASK);
        const ResonanceSet& set = data_[idx];

        // Prefetch both cache lines for this set.
        _mm_prefetch((const char*)&set, _MM_HINT_T0);
        _mm_prefetch((const char*)&set + 64, _MM_HINT_T0);

        uint16_t best = 0, second = 0;
        int best_i = -1;

        #pragma unroll
        for (int i = 0; i < FIGHTER_WAYS; ++i) {
            const ResonanceEntry& e = set.ways[i];
            if (e.hits == 0) continue; // empty

            const uint16_t m = match_bits_128(sig, e.sig);
            if (m > best) { second = best; best = m; best_i = i; }
            else if (m > second) { second = m; }
        }

        r.best_match = best;
        r.second_match = second;
        if (best_i >= 0 && best >= threshold) {
            r.hit = true;
            r.best_way = (uint8_t)best_i;
            r.tok0 = set.ways[best_i].tok[0];
        }
        return r;
    }

    // Reinforce / insert mapping: sig -> (tok0,q8).
    // Eviction policy:
    // 1) exact sig match => update
    // 2) empty slot
    // 3) least hits (fitness)
    // 4) if tie, oldest age
    void reinforce(const uint32_t sig[4], uint16_t tok0, int8_t q8_0, uint16_t age_now) {
        const uint32_t idx = set_index_128(sig, MASK);
        ResonanceSet& set = data_[idx];

        // 1) exact match
        for (int i = 0; i < FIGHTER_WAYS; ++i) {
            ResonanceEntry& e = set.ways[i];
            if (e.hits == 0) continue;

            // fast check: first 64 bits then memcmp
            const uint64_t* ea = (const uint64_t*)e.sig;
            const uint64_t* sa = (const uint64_t*)sig;
            if (ea[0] == sa[0] && std::memcmp(e.sig, sig, 16) == 0) {
                if (e.hits < 0xFFFFu) e.hits++;
                e.tok[0] = tok0;
                e.q8[0] = q8_0;
                e.age = age_now;
                return;
            }
        }

        // 2) empty slot
        int target = -1;
        for (int i = 0; i < FIGHTER_WAYS; ++i) {
            if (set.ways[i].hits == 0) { target = i; break; }
        }

        // 3/4) choose eviction
        if (target < 0) {
            uint16_t min_hits = 0xFFFFu;
            uint16_t oldest_age = 0;
            target = 0;
            for (int i = 0; i < FIGHTER_WAYS; ++i) {
                const ResonanceEntry& e = set.ways[i];
                if (e.hits < min_hits) {
                    min_hits = e.hits;
                    oldest_age = e.age;
                    target = i;
                } else if (e.hits == min_hits) {
                    // prefer older
                    if ((uint16_t)(age_now - e.age) > (uint16_t)(age_now - oldest_age)) {
                        oldest_age = e.age;
                        target = i;
                    }
                }
            }
        }

        ResonanceEntry& e = set.ways[target];
        std::memcpy(e.sig, sig, 16);
        e.tok[0] = tok0;
        e.q8[0] = q8_0;
        e.hits = 1;
        e.age = age_now;

        // Optional: clear remaining TOPK slots (kept deterministic)
        #if FIGHTER_TOPK > 1
        for (int k = 1; k < FIGHTER_TOPK; ++k) {
            e.tok[k] = tok0;
            e.q8[k] = q8_0;
        }
        #endif
    }

private:
    ResonanceSet* data_ = nullptr;
};
