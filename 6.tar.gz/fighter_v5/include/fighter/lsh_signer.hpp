#pragma once

#include <immintrin.h>
#include <cstdint>

// Simple deterministic PRNG for building hyperplane tables.
static inline uint32_t xorshift32(uint32_t& s) {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
}

// 128-bit signature = 16 groups * 8 bits. Each group computes 8 hyperplanes.
// State is 16 floats. Table stores +/-1 weights per hyperplane.
struct alignas(32) LSHProjTable {
    // [group][dim] -> __m256 lanes are 8 hyperplanes.
    __m256 sign[16][16];
};

static inline void build_lsh_table(LSHProjTable& tab, const uint32_t seeds[512]) {
    for (int g = 0; g < 16; ++g) {
        for (int d = 0; d < 16; ++d) {
            uint32_t s = seeds[(g * 16 + d) & 511];
            alignas(32) float tmp[8];
            for (int lane = 0; lane < 8; ++lane) {
                tmp[lane] = (xorshift32(s) & 1u) ? 1.0f : -1.0f;
            }
            tab.sign[g][d] = _mm256_load_ps(tmp);
        }
    }
}

// Convert state16 -> 128-bit LSH signature.
// out_sig holds 4x32 = 128 bits. Bit order is stable and deterministic.
static inline void make_state_sig_lsh128(const float state16[16], const LSHProjTable& tab, uint32_t out_sig[4]) {
    out_sig[0] = out_sig[1] = out_sig[2] = out_sig[3] = 0u;

    for (int g = 0; g < 16; ++g) {
        __m256 acc = _mm256_setzero_ps();
        // 8 hyperplanes computed in parallel.
        for (int d = 0; d < 16; ++d) {
            acc = _mm256_fmadd_ps(_mm256_set1_ps(state16[d]), tab.sign[g][d], acc);
        }
        // movemask gives 8 sign bits (1 if negative). This is fine: it's a stable split.
        uint32_t bits8 = (uint32_t)_mm256_movemask_ps(acc);
        out_sig[g >> 2] |= (bits8 << ((g & 3) << 3));
    }
}
