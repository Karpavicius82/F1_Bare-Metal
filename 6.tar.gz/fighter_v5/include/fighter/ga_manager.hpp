#pragma once

#include <cstdint>

// Runtime adaptation: adjust acceptance threshold based on uncertainty and backpressure.
// This is NOT "training"; it's a control loop so the system stays stable.

struct ManagerMetrics {
    uint64_t lookups = 0;
    uint64_t hits = 0;
    uint64_t misses = 0;
    uint64_t pushed = 0;
    uint64_t overflows = 0;

    uint32_t threshold = 96;      // match bits out of 128
    uint32_t miss_streak = 0;
    uint32_t overflow_streak = 0;
};

// Entropy friction: best vs second-best gap.
// - If gap is small: ambiguous => tighten threshold.
// - If gap is large: very confident => can loosen slightly.
static inline void ga_adjust_threshold(ManagerMetrics& m,
                                      uint16_t best,
                                      uint16_t second,
                                      bool hit,
                                      bool push_ok) {
    const int gap = int(best) - int(second);
    const bool uncertain = (gap < 8);
    const bool very_conf = (gap > 24);

    if (hit) {
        m.miss_streak = 0;
        if (uncertain) {
            m.threshold += 1;
        } else if (very_conf) {
            if (m.threshold > 64 && best > m.threshold + 6) m.threshold -= 1;
        }
    } else {
        m.miss_streak++;
        // if too many misses, relax slowly
        if (m.miss_streak >= 128) {
            if (m.threshold > 64) m.threshold -= 1;
            m.miss_streak = 0;
        }
    }

    if (!push_ok) {
        m.overflow_streak++;
        // backpressure: if the bridge fills up, become stricter immediately
        if (m.threshold < 124) m.threshold += 1;
        if (m.overflow_streak >= 32) {
            // hard clamp reaction
            if (m.threshold < 124) m.threshold += 1;
            m.overflow_streak = 0;
        }
    } else {
        m.overflow_streak = 0;
    }

    if (m.threshold < 64)  m.threshold = 64;
    if (m.threshold > 124) m.threshold = 124;
}
