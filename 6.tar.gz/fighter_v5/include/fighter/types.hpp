#pragma once

#include <atomic>
#include <cstdint>
#include <cstring>

// Command consumed by Worker at refresh points.
// Keep POD and small to stay in L1.
struct StepCommand {
    uint32_t token_id;     // decision from head (or teacher fallback)
    uint32_t inject_idx;   // payload index for optional state injection
    uint16_t match_bits;   // similarity 0..128 (higher is better)
    uint16_t target_slot;  // 0=short (state[0..7]), 1=long (state[8..15])
    int16_t  mix_q14;      // Q1.14 injection strength
    uint16_t flags;        // bit0=HAS_INJECT
};
// StepCommand::flags bits
static constexpr uint16_t CMD_HAS_INJECT = 1u << 0;
static constexpr uint16_t CMD_FROM_TEACHER = 1u << 1;


// Single-producer (Manager) / single-consumer (Worker) lock-free ring.
// Padding prevents false sharing on head/tail.
struct alignas(64) ResonanceBridge {
    alignas(64) std::atomic<uint64_t> head{0};
    uint8_t pad0[56];
    alignas(64) std::atomic<uint64_t> tail{0};
    uint8_t pad1[56];

    StepCommand q[16]; // small, ultra-low-latency

    bool push(const StepCommand& c) {
        uint64_t t = tail.load(std::memory_order_relaxed);
        uint64_t h = head.load(std::memory_order_acquire);
        if (t - h >= 16) return false;
        q[t & 15] = c;
        tail.store(t + 1, std::memory_order_release);
        return true;
    }

    bool pop(StepCommand& c) {
        uint64_t h = head.load(std::memory_order_relaxed);
        uint64_t t = tail.load(std::memory_order_acquire);
        if (h == t) return false;
        c = q[h & 15];
        head.store(h + 1, std::memory_order_release);
        return true;
    }
};

// Worker publishes its current signature to Manager via a seq-lock.
struct alignas(64) StateSketch {
    std::atomic<uint32_t> seq{0}; // even=stable, odd=writing
    uint32_t sig[4]{0, 0, 0, 0};

    inline void write(const uint32_t in_sig[4]) {
        uint32_t s0 = seq.load(std::memory_order_relaxed);
        seq.store(s0 + 1, std::memory_order_release);
        std::memcpy(sig, in_sig, 16);
        seq.store(s0 + 2, std::memory_order_release);
    }

    inline bool read(uint32_t out_sig[4]) const {
        uint32_t a0, a1;
        do {
            a0 = seq.load(std::memory_order_acquire);
            if (a0 & 1u) continue;
            std::memcpy(out_sig, sig, 16);
            a1 = seq.load(std::memory_order_acquire);
        } while (a0 != a1 || (a1 & 1u));
        return true;
    }
};
